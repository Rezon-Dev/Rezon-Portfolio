import { Mail, ArrowUpRight } from "lucide-react"

const socialLinks = [
  { name: "Twitter/X", href: "#" },
  { name: "LinkedIn", href: "#" },
  { name: "Medium", href: "#" },
  { name: "Instagram", href: "#" },
]

export function ContactSection() {
  return (
    <section id="contact" className="py-24 md:py-32 px-6 bg-card">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16">
          <div>
            <div className="flex items-center gap-4 mb-8">
              <div className="h-px w-12 bg-primary"></div>
              <span className="text-primary text-sm tracking-widest uppercase">Contact</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-6 text-balance">
              Let&apos;s connect and create something meaningful
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              Whether you have a project in mind, want to collaborate, or simply want to 
              discuss literature and writing, I&apos;d love to hear from you.
            </p>
          </div>

          <div className="space-y-8">
            <div>
              <h3 className="text-sm text-muted-foreground uppercase tracking-wider mb-4">Email</h3>
              <a 
                href="mailto:hello@rezonhaque.com" 
                className="text-xl text-foreground hover:text-primary transition-colors flex items-center gap-2 group"
              >
                <Mail className="h-5 w-5 text-primary" />
                hello@rezonhaque.com
                <ArrowUpRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
              </a>
            </div>

            <div>
              <h3 className="text-sm text-muted-foreground uppercase tracking-wider mb-4">Social Media</h3>
              <ul className="space-y-3">
                {socialLinks.map((link) => (
                  <li key={link.name}>
                    <a 
                      href={link.href}
                      className="text-foreground hover:text-primary transition-colors flex items-center gap-2 group"
                    >
                      {link.name}
                      <ArrowUpRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
