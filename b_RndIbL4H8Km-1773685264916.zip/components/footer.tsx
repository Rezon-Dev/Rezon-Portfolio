export function Footer() {
  return (
    <footer className="py-8 px-6 border-t border-border">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
        <p className="text-sm text-muted-foreground">
          © {new Date().getFullYear()} Rezon Haque. All rights reserved.
        </p>
        <p className="text-sm text-muted-foreground">
          Crafted with passion and purpose
        </p>
      </div>
    </footer>
  )
}
