import { BookOpen, Camera, Music, Coffee, Pen, Globe } from "lucide-react"

const interests = [
  {
    icon: BookOpen,
    title: "Literature",
    description: "From classic novels to contemporary poetry, I find endless inspiration in the written word.",
  },
  {
    icon: Pen,
    title: "Journaling",
    description: "Daily reflections and observations that fuel my creative process and self-discovery.",
  },
  {
    icon: Camera,
    title: "Photography",
    description: "Capturing moments and stories through a visual lens, complementing my written narratives.",
  },
  {
    icon: Music,
    title: "Music",
    description: "Finding rhythm in melodies that inspire the cadence and flow of my writing.",
  },
  {
    icon: Coffee,
    title: "Café Culture",
    description: "Writing in cozy corners of coffee shops, where creativity meets caffeine.",
  },
  {
    icon: Globe,
    title: "Travel",
    description: "Seeking new perspectives and stories from different cultures and landscapes.",
  },
]

export function InterestsSection() {
  return (
    <section id="interests" className="py-24 md:py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <div className="h-px w-12 bg-primary"></div>
          <span className="text-primary text-sm tracking-widest uppercase">Interests</span>
        </div>
        
        <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4 text-balance">
          Beyond the Page
        </h2>
        <p className="text-muted-foreground max-w-2xl mb-12">
          The passions and pursuits that shape my perspective and enrich my writing.
        </p>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {interests.map((interest, index) => (
            <div 
              key={index}
              className="group"
            >
              <div className="flex items-center gap-4 mb-4">
                <div className="p-3 bg-secondary rounded-lg group-hover:bg-primary/10 transition-colors">
                  <interest.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-lg font-medium text-foreground">{interest.title}</h3>
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed pl-16">
                {interest.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
