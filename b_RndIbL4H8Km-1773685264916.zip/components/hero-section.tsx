import { ArrowDown } from "lucide-react"

export function HeroSection() {
  return (
    <section id="home" className="min-h-screen flex flex-col justify-center px-6 pt-20">
      <div className="max-w-6xl mx-auto w-full">
        <div className="max-w-3xl">
          <p className="text-primary text-sm tracking-widest uppercase mb-4">
            Student Writer
          </p>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-foreground mb-6 leading-tight text-balance">
            Rezon Haque
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl">
            <span className="italic font-serif text-foreground">Crafting stories.</span>{" "}
            A student writer passionate about exploring the human experience through words. 
            I believe in the power of storytelling to connect, inspire, and transform.
          </p>
          
          <div className="mt-12 flex items-center gap-8">
            <div className="h-px w-16 bg-primary"></div>
            <a 
              href="#about"
              className="text-sm text-muted-foreground hover:text-primary transition-colors flex items-center gap-2 group"
            >
              Explore my work
              <ArrowDown className="h-4 w-4 group-hover:translate-y-1 transition-transform" />
            </a>
          </div>
        </div>

        <div className="mt-24 grid grid-cols-3 gap-8 max-w-md">
          <div>
            <p className="text-3xl font-serif text-foreground">12+</p>
            <p className="text-sm text-muted-foreground mt-1">Published Works</p>
          </div>
          <div>
            <p className="text-3xl font-serif text-foreground">3</p>
            <p className="text-sm text-muted-foreground mt-1">Years Writing</p>
          </div>
          <div>
            <p className="text-3xl font-serif text-foreground">5</p>
            <p className="text-sm text-muted-foreground mt-1">Awards</p>
          </div>
        </div>
      </div>
    </section>
  )
}
