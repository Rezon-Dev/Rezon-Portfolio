import { ArrowUpRight } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

const writings = [
  {
    title: "Echoes of Tomorrow",
    category: "Short Story",
    description: "A contemplative piece exploring memory and time through the eyes of an elderly writer looking back on their life.",
    year: "2025",
  },
  {
    title: "City Lights, Empty Streets",
    category: "Poetry Collection",
    description: "A series of poems capturing the solitude and beauty of urban life after midnight.",
    year: "2025",
  },
  {
    title: "The Art of Listening",
    category: "Essay",
    description: "An exploration of how truly listening to others can transform our understanding of the world.",
    year: "2024",
  },
  {
    title: "Between the Lines",
    category: "Creative Non-Fiction",
    description: "Personal reflections on the lessons hidden within everyday conversations and encounters.",
    year: "2024",
  },
]

export function WritingSection() {
  return (
    <section id="writing" className="py-24 md:py-32 px-6 bg-card">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <div className="h-px w-12 bg-primary"></div>
          <span className="text-primary text-sm tracking-widest uppercase">Writing</span>
        </div>
        
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground text-balance">
            Selected Works
          </h2>
          <p className="text-muted-foreground max-w-md">
            A collection of my recent writings spanning various genres and themes.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {writings.map((work, index) => (
            <Card 
              key={index} 
              className="bg-secondary/30 border-border hover:border-primary/50 transition-all duration-300 group cursor-pointer"
            >
              <CardContent className="p-6 md:p-8">
                <div className="flex items-start justify-between mb-4">
                  <span className="text-xs text-primary tracking-wider uppercase">{work.category}</span>
                  <span className="text-sm text-muted-foreground">{work.year}</span>
                </div>
                <h3 className="text-xl font-serif font-semibold text-foreground mb-3 group-hover:text-primary transition-colors flex items-center gap-2">
                  {work.title}
                  <ArrowUpRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {work.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a 
            href="#" 
            className="inline-flex items-center gap-2 text-primary hover:text-primary/80 transition-colors group"
          >
            View all works
            <ArrowUpRight className="h-4 w-4 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
          </a>
        </div>
      </div>
    </section>
  )
}
