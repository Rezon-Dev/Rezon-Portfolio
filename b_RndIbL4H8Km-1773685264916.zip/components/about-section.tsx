export function AboutSection() {
  return (
    <section id="about" className="py-24 md:py-32 px-6">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-16 items-start">
          <div>
            <div className="flex items-center gap-4 mb-8">
              <div className="h-px w-12 bg-primary"></div>
              <span className="text-primary text-sm tracking-widest uppercase">About</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-6 text-balance">
              A journey through words and imagination
            </h2>
          </div>

          <div className="space-y-6">
            <p className="text-muted-foreground leading-relaxed">
              Hello! I&apos;m Rezon Haque, a student writer with a deep passion for literature and 
              creative expression. Currently pursuing my studies, I spend my days exploring 
              the intersection of academics and artistic writing.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              My writing journey began with poetry, finding rhythm and meaning in carefully 
              chosen words. Since then, I&apos;ve expanded into short stories, essays, and 
              creative non-fiction, always seeking new ways to capture the complexity of 
              human emotions and experiences.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              I believe that every story deserves to be told with authenticity and care. 
              Whether it&apos;s a reflection on daily life or an exploration of abstract concepts, 
              I approach each piece with curiosity and dedication.
            </p>
            
            <div className="pt-6 grid grid-cols-2 gap-6">
              <div className="border-l-2 border-primary pl-4">
                <p className="text-foreground font-medium">Education</p>
                <p className="text-sm text-muted-foreground mt-1">BA English Literature</p>
              </div>
              <div className="border-l-2 border-primary pl-4">
                <p className="text-foreground font-medium">Focus</p>
                <p className="text-sm text-muted-foreground mt-1">Poetry & Short Fiction</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
